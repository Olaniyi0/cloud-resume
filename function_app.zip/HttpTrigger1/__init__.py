import azure.functions as func
from os import environ
from azure.cosmosdb.table import TableService

def main(req: func.HttpRequest, messageJSON) -> func.HttpResponse:

    connection_string = environ.get("RESUMEDB_CONNECTION_STRING")

    table_service = TableService(endpoint_suffix = "table.cosmos.azure.com", connection_string=connection_string)
    num_of_visitors = int(table_service.get_entity(table_name="visitors", partition_key="visitorsCount", row_key="1")['NumberOfVisitors']) + 1
    data = {
        "NumberOfVisitors": num_of_visitors,
        "PartitionKey": "visitorsCount",
        "RowKey": "1"
    }
    
    table_service.update_entity(table_name="visitors", entity=data)

    return func.HttpResponse(f"{num_of_visitors}")